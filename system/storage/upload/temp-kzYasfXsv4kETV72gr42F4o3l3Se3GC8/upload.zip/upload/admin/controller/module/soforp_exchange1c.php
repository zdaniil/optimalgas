<?php

require_once(DIR_SYSTEM . "/engine/soforp_controller.php");

$shutdown_redirect = "";
function soforp_exchange1c_shutdown()
{
    global $shutdown_redirect;
    if ($shutdown_redirect)
        header("location: " . $shutdown_redirect);
}

class ControllerModuleSoforpExchange1c extends SoforpController
{
    private $error = array();

    public function __construct($registry)
    {
        parent::__construct($registry);
        $this->_moduleName = "";
        $this->_moduleSysName = "soforp_exchange1c";
        $this->debug = $this->config->get($this->_moduleSysName . "_debug");
        $this->_logFile = $this->_moduleSysName . ".log";
    }

    public function index()
    {
        global $shutdown_redirect;

        if (!function_exists('ioncube_file_info') && $this->language->get("soforp_exchange1c_nocube") != "1") {
            $this->response->redirect($this->url->link('module/soforp_exchange1c/ioncube', 'token=' . $this->session->data['token'], 'SSL'));
            return;
        } else {
            $shutdown_redirect = str_replace("&amp;", "&", $this->url->link('module/soforp_exchange1c/license', 'token=' . $this->session->data['token'], 'SSL'));
            register_shutdown_function('soforp_exchange1c_shutdown');
            require_once(DIR_APPLICATION . "model/tool/soforp_exchange1c.php");
            $shutdown_redirect = "";
        }

        $data = $this->language->load('module/soforp_exchange1c');
        $this->load->model('tool/image');

        $this->document->setTitle($this->language->get('heading_title_raw'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('soforp_exchange1c', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            if( isset($this->request->get['close']) ) {
                $this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
            } else {
                $this->response->redirect($this->url->link('module/soforp_exchange1c', 'token=' . $this->session->data['token'], 'SSL'));
            }
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else if (isset($this->session->data['warning'])) {
            $data['error_warning'] = $this->session->data['warning'];
            unset($this->session->data['warning']);
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        }

        $data = $this->initBreadcrumbs(array(
            array("extension/module", "text_module"),
            array("module/soforp_exchange1c", "heading_title_raw")
        ), $data);


        $data['token'] = $this->session->data['token'];
        $data['save'] = $this->url->link('module/soforp_exchange1c', 'token=' . $this->session->data['token'], 'SSL');
        $data['import'] = $this->url->link('tool/soforp_exchange1c/import', 'token=' . $this->session->data['token'], 'SSL');
        $data['export'] = $this->url->link('tool/soforp_exchange1c/export', 'token=' . $this->session->data['token'], 'SSL');
        $data['export_product'] = $this->url->link('tool/soforp_exchange1c/export_product', 'token=' . $this->session->data['token'], 'SSL');
        $data['save_and_close'] = $this->url->link('module/soforp_exchange1c', 'token=' . $this->session->data['token'] . "&close=1", 'SSL');
        $data['close'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');
        $data['check_password'] = $this->url->link('module/soforp_exchange1c/check_password', 'token=' . $this->session->data['token'], 'SSL');
        $data['soforp_exchange1c_link'] = rtrim(HTTP_CATALOG,"/") . "/export/soforp_exchange1c.php";
        $data['clear'] = $this->url->link('module/soforp_exchange1c/clear', 'token=' . $this->session->data['token'], 'SSL');

        $data['delete_orders'] = $this->url->link('tool/soforp_exchange1c/delete_orders', 'token=' . $this->session->data['token'], 'SSL');
        $data['get_orders'] = $this->url->link('tool/soforp_exchange1c/get_orders', 'token=' . $this->session->data['token'], 'SSL');
        $data['delete_categories'] = $this->url->link('tool/soforp_exchange1c/delete_categories', 'token=' . $this->session->data['token'], 'SSL');
        $data['delete_manufacturers'] = $this->url->link('tool/soforp_exchange1c/delete_manufacturers', 'token=' . $this->session->data['token'], 'SSL');
        $data['delete_products'] = $this->url->link('tool/soforp_exchange1c/delete_products', 'token=' . $this->session->data['token'], 'SSL');
		$data['delete_products_warehouses'] = $this->url->link('tool/soforp_exchange1c/delete_products_warehouses', 'token=' . $this->session->data['token'], 'SSL');
        $data['delete_attributes'] = $this->url->link('tool/soforp_exchange1c/delete_attributes', 'token=' . $this->session->data['token'], 'SSL');
        $data['delete_options'] = $this->url->link('tool/soforp_exchange1c/delete_options', 'token=' . $this->session->data['token'], 'SSL');
        $data['delete_links'] = $this->url->link('tool/soforp_exchange1c/delete_links', 'token=' . $this->session->data['token'], 'SSL');

        $data = $this->initParams(array(
            array($this->_moduleSysName . "_status", 1),
            array($this->_moduleSysName . "_debug", 1),
            array($this->_moduleSysName . "_sql_before", ""),
            array($this->_moduleSysName . "_sql_after", ""),
            array($this->_moduleSysName . "_username", ""),
            array($this->_moduleSysName . "_password", ""),
            array($this->_moduleSysName . "_ip_list", ""),
            array($this->_moduleSysName . "_fill_parent_cats", 0),
            array($this->_moduleSysName . "_price_name", "" ),
            array($this->_moduleSysName . "_product_status", 1 ),
            array($this->_moduleSysName . "_product_stock_status", 1 ),
            array($this->_moduleSysName . "_update_name", 0 ),
            array($this->_moduleSysName . "_update_description", 0),
            array($this->_moduleSysName . "_update_price", 1 ),
            array($this->_moduleSysName . "_update_sku", 0 ),
            array($this->_moduleSysName . "_update_quantity", 1 ),
            array($this->_moduleSysName . "_create_attribute", 0),
            array($this->_moduleSysName . "_update_attribute", 0),
            array($this->_moduleSysName . "_update_categories", 0),
            array($this->_moduleSysName . "_update_images", 1),
            array($this->_moduleSysName . "_create_product", 1),
            array($this->_moduleSysName . "_lookup_product", 0),
            array($this->_moduleSysName . "_create_category", 0),
            array($this->_moduleSysName . "_category_status", 0),
            array($this->_moduleSysName . "_category_links", ""),
            array($this->_moduleSysName . "_category_top_status", 0),
            array($this->_moduleSysName . "_category_update_name", 0),
            array($this->_moduleSysName . "_create_manufacturer", 0),
            array($this->_moduleSysName . "_create_option", 0),
            array($this->_moduleSysName . "_update_option", 0),
            array($this->_moduleSysName . "_customer_phone", 0),
            array($this->_moduleSysName . "_order_status_notify", 0),
            array($this->_moduleSysName . "_order_date", "" ),
            array($this->_moduleSysName . "_order_currency", ""),
            array($this->_moduleSysName . "_order_utf8", 1),
            array($this->_moduleSysName . "_final_order_status", 2),
            array($this->_moduleSysName . "_order_statuses", array(1)),
            array($this->_moduleSysName . "_product_subtract", 0),
            array($this->_moduleSysName . "_product_fullname", 0),
            array($this->_moduleSysName . "_use_warehouse", 0),
            array($this->_moduleSysName . "_main_warehouse", ""),
            array($this->_moduleSysName . "_use_related_options", 0),
            array($this->_moduleSysName . "_ignore_attributes", "ОписаниеФайла\nВидНоменклатуры\nТипНоменклатуры\nПолное наименование\nID Class365\nСЕО_УРЛ"),
            array($this->_moduleSysName . "_unit_field", ""),
            array($this->_moduleSysName . "_order_customer", ""),
            array($this->_moduleSysName . "_code_field", "upc"),
            array($this->_moduleSysName . "_barcode_field", "ean"),
            array($this->_moduleSysName . "_option_price", 0),
            array($this->_moduleSysName . "_order_shipping_links", ""),
            //array($this->_moduleSysName . "_order_payment_links", ""),
            array($this->_moduleSysName . "_order_total_links", ""),
			array($this->_moduleSysName . "_unit_links", ""),
            array($this->_moduleSysName . "_currency_convertor", ""),
            array($this->_moduleSysName . "_delete_zero_option", 0),
            array($this->_moduleSysName . "_disable_missing", 0),
            array($this->_moduleSysName . "_enable_zip", 0),
            array($this->_moduleSysName . "_extra_comment", 0),
            array($this->_moduleSysName . "_price_special", ""),

            array($this->_moduleSysName . "_option_type", 0),
            array($this->_moduleSysName . "_option_required", 0),
            array($this->_moduleSysName . "_option_by_box", 0),
            array($this->_moduleSysName . "_totals_positive", 0),
            array($this->_moduleSysName . "_attribute_routing", ""),
            array($this->_moduleSysName . "_missing_quantity_is_zero", 0),
			array($this->_moduleSysName . "_delete_offers", 0),

            array($this->_moduleSysName . "_price_type", array(array(
                'keyword'			=> '',
                'customer_group_id'	=> 0,
                'quantity'			=> 0,
                'priority'			=> 0
            ))),
            array($this->_moduleSysName . "_update_filter", 0 ),

        ), $data);

        if( substr(VERSION,0,3) == "2.0") {
            $this->load->model('sale/customer_group');
            $data['customer_groups'] = $this->model_sale_customer_group->getCustomerGroups();
        } else {
            $this->load->model('customer/customer_group');
            $data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();
        }

        $this->load->model('localisation/stock_status');

        $results = $this->model_localisation_stock_status->getStockStatuses();
        $stock_statuses = array();
        foreach ($results as $result) {
            $stock_statuses[$result['stock_status_id']] = $result['name'];
        }
        $data['stock_statuses'] = $stock_statuses;

        $this->load->model('localisation/order_status');

        $order_statuses = $this->model_localisation_order_status->getOrderStatuses();
        $statuses = array();
        foreach ($order_statuses as $order_status) {
            $statuses[ $order_status['order_status_id'] ] = $order_status['name'];
        }
        $data['order_statuses'] = $statuses;

        $data['params'] = $data;

        $data["logs"] = $this->getLogs();

        $this->load->model("module/soforp_exchange1c");
        $this->model_module_soforp_exchange1c->upgrade();

        // API login
        $this->load->model('user/api');

        $api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

        if ($api_info) {
            $data['api_id'] = $api_info['api_id'];
            $data['api_key'] = $api_info['key'];
            $data['api_ip'] = $this->request->server['REMOTE_ADDR'];
        } else {
            $data['api_id'] = '';
            $data['api_key'] = '';
            $data['api_ip'] = '';
        }

        $data['store'] = HTTPS_CATALOG;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/soforp_exchange1c.tpl', $data));
    }


    public function clear()
    {
        $data = $this->language->load('module/soforp_exchange1c');

        if (is_file(DIR_LOGS . $this->_logFile)) {
            $f = fopen(DIR_LOGS . $this->_logFile, "w");
            fclose($f);
            $this->session->data['success'] = $this->language->get('text_success_clear');
        }

        $this->response->redirect($this->url->link('module/soforp_exchange1c', 'token=' . $this->session->data['token'], 'SSL'));
    }

    public function license()
    {
        $data = $this->language->load('module/soforp_exchange1c');

        $this->document->setTitle($this->language->get('heading_title_raw'));

        $data = $this->initBreadcrumbs(array(
            array("extension/module", "text_module"),
            array("module/soforp_exchange1c", "heading_title_raw")
        ), $data);

        $data['error_warning'] = "";

        $data['close'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');
        $data['recheck'] = $this->url->link('module/soforp_exchange1c', 'token=' . $this->session->data['token'], 'SSL');

        $data['license_error'] = $this->language->get('error_license_missing');
        $data['params'] = $data;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/soforp_exchange1c.tpl', $data));
    }

    public function ioncube()
    {
        $data = $this->language->load('module/soforp_exchange1c');

        $this->document->setTitle($this->language->get('heading_title_raw'));

        $data = $this->initBreadcrumbs(array(
            array("extension/module", "text_module"),
            array("module/soforp_exchange1c", "heading_title_raw")
        ), $data);

        $data['error_warning'] = "";
        $data['params'] = $data;

        $data['close'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');
        $data['recheck'] = $this->url->link('module/soforp_exchange1c', 'token=' . $this->session->data['token'], 'SSL');

        $data['license_error'] = $this->language->get('error_ioncube_missing');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/soforp_exchange1c.tpl', $data));
    }

    public function install()
    {
        $this->load->model("module/soforp_exchange1c");
        $this->model_module_soforp_exchange1c->install();
    }

    public function uninstall()
    {
        $this->load->model("module/soforp_exchange1c");
        $this->model_module_soforp_exchange1c->uninstall();
    }

    private function validate()
    {

        if (!$this->user->hasPermission('modify', 'module/soforp_exchange1c')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

}

?>
