<?php
require_once( DIR_SYSTEM . "/engine/soforp_model.php");

class ModelModuleSoforpExchange1c extends SoforpModel {

    public function __construct($registry) {
        parent::__construct($registry);
        $this->_moduleName = "";
        $this->debug = $this->config->get("soforp_exchange1c_debug");
        $this->_logFile = "soforp_exchange1c.log";
    }


    protected function installTables(){
        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'product_to_1c` (
				`product_id` int(11) NOT NULL,
				`1c_id` varchar(255) NOT NULL,
				KEY (`product_id`),
				KEY `1c_id` (`1c_id`)
            ) DEFAULT CHARSET=utf8'
        );

        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'category_to_1c` (
				`category_id` int(11) NOT NULL,
				`1c_id` varchar(255) NOT NULL,
				KEY (`category_id`),
				KEY `1c_id` (`1c_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8'
        );

        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'warehouse` (
				`warehouse_id` int(11) NOT NULL AUTO_INCREMENT,
				`name` varchar(255) NOT NULL,
				`1c_id` varchar(255) NOT NULL,
				PRIMARY KEY (`warehouse_id`),
				KEY `1c_id` (`1c_id`)
            ) DEFAULT CHARSET=utf8'
        );

		$this->db->query(
			'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'warehouse_to_store` (
				`warehouse_id` int(11),
				`store_id` int(11),
				KEY `warehouse_id` (`warehouse_id`),
				KEY `store_id` (`store_id`)
            ) DEFAULT CHARSET=utf8'
		);

        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'warehouse_description` (
				`warehouse_id` int(11) NOT NULL,
				`language_id` int(11) NOT NULL,
				`param1` varchar(255) NOT NULL,
				`param2` varchar(255) NOT NULL,
				`param3` varchar(255) NOT NULL,
				`param4` varchar(255) NOT NULL,
				`param5` varchar(255) NOT NULL,
				KEY (`warehouse_id`)
            ) DEFAULT CHARSET=utf8'
        );

        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'product_warehouse` (
				`product_warehouse_id` int(11) NOT NULL AUTO_INCREMENT,
				`product_id` int(11) NOT NULL,
				`warehouse_id` int(11) NOT NULL,
				`quantity` varchar(255) NOT NULL,
				PRIMARY KEY (`product_warehouse_id`),
				KEY `product_id` (`product_id`),
				KEY `warehouse_id` (`warehouse_id`)
            ) DEFAULT CHARSET=utf8'
        );

		$this->db->query(
			'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'order_warehouse` (
				`order_warehouse_id` int(11) NOT NULL AUTO_INCREMENT,
				`order_id` int(11) NOT NULL,
				`order_product_id` int(11) NOT NULL,
				`warehouse_id` int(11) NOT NULL,
				PRIMARY KEY (`order_warehouse_id`)			
			) DEFAULT CHARSET=utf8;'
		);

		$this->db->query(
			'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'order_warehouse` (
				`order_warehouse_id` int(11) NOT NULL,
				`order_id` int(11) NOT NULL,
				`order_product_id` int(11) NOT NULL,
				`warehouse_id` int(11) NOT NULL
			) DEFAULT CHARSET=utf8;'
		);

		$this->db->query(
			'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'product_option_warehouse` (
				`product_warehouse_id` int(11) NOT NULL AUTO_INCREMENT,
				`product_id` int(11) NOT NULL,
				`product_option_value_id` int(11) NOT NULL,
				`warehouse_id` int(11) NOT NULL,
				`quantity` varchar(255) NOT NULL,
				PRIMARY KEY (`product_warehouse_id`),
				KEY `product_option_value_id` (`product_option_value_id`),
				KEY `warehouse_id` (`warehouse_id`)
            ) DEFAULT CHARSET=utf8'
		);

		$this->db->query(
			'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'product_related_option_warehouse` (
				`product_warehouse_id` int(11) NOT NULL AUTO_INCREMENT,
				`product_id` int(11) NOT NULL,
				`related_option_id` int(11) NOT NULL,
				`warehouse_id` int(11) NOT NULL,
				`quantity` varchar(255) NOT NULL,
				PRIMARY KEY (`product_warehouse_id`),
				KEY `product_option_id` (`product_id`,`related_option_id`),
				KEY `warehouse_id` (`warehouse_id`)
            ) DEFAULT CHARSET=utf8'
		);

        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'product_option_to_1c` (
				`product_id` int(11) NOT NULL,
				`product_option_value_id` int(11) NOT NULL,
				`related_option_id` int(11) NOT NULL,
				`1c_id` varchar(255) NOT NULL,
				KEY `product_to_option` (`product_id`,`product_option_value_id`),
				KEY `product_to_related_option` (`product_id`,`related_option_id`)
            ) DEFAULT CHARSET=utf8'
        );

        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'property_1c` (
				`property_id` varchar(255) NOT NULL,
				`name` varchar(255) NOT NULL,
				PRIMARY KEY (`property_id`),
				KEY `name` (`name`)
            ) DEFAULT CHARSET=utf8'
        );

        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'property_value_1c` (
				`property_value_id` varchar(255) NOT NULL,
				`property_id` varchar(255) NOT NULL,
				`value` varchar(255) NOT NULL,
				KEY `property_value_id` (`property_value_id`),
				KEY `property_id` (`property_id`),
				KEY `value` (`value`)
            ) DEFAULT CHARSET=utf8'
        );
    }

    public function upgrade(){
        $this->installTables();

        // category_to_1c.1c_category_id => 1c_id
        $sql = "SHOW COLUMNS FROM `" . DB_PREFIX . "category_to_1c` LIKE '1c_category_id'";
        $query = $this->db->query($sql);
        if( $query->num_rows ) {
            $sql = "ALTER TABLE " . DB_PREFIX . "category_to_1c CHANGE `1c_category_id` `1c_id` VARCHAR(64)";
            $this->db->query($sql);
        }

        $hasNewIndex = false;
        $sql = "SHOW INDEX FROM `" . DB_PREFIX . "category_to_1c`";
        $query = $this->db->query($sql);
        foreach($query->rows as $row) {
            if( $row['Key_name'] == '1c_id') {
                $hasNewIndex = true;
            }
            if( $row['Key_name'] == '1c_category_id') {
                $sql = "ALTER TABLE " . DB_PREFIX . "category_to_1c DROP INDEX 1c_category_id";
                $this->db->query($sql);
            }
        }
        if( !$hasNewIndex) {
            $sql = "ALTER TABLE " . DB_PREFIX . "category_to_1c ADD INDEX  `1c_id` (  `1c_id` )";
            $this->db->query($sql);
        }
    }

    public function install() {

        // Недостающие таблицы
        $this->installTables();

        // Недостающие права
        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'tool/soforp_exchange1c');
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'tool/soforp_exchange1c');
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'catalog/soforp_warehouse');
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'catalog/soforp_warehouse');

        return TRUE;
    }

    public function uninstall() {

        return TRUE;
    }

}
?>